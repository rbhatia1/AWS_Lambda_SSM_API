import boto3
import os
import json

region = 'us-east-1'
ec2 = boto3.resource('ec2')

def lambda_handler(event, context):
    reqMethod = event["httpMethod"]
    reqPath = event["path"]
    if (reqMethod == "GET" and reqPath == "/check/test"):
        content = event["queryStringParameters"]
        KV = content["KV"]
        KN = content["KN"]
        
        
        search1 = ("[{'Name': 'tag:" + KN + "', 'Values': ['" + KV + "']}]")
        instances = ec2.instances.filter(Filters=eval(search1))
    
        RunningInstances = [instance.id for instance in instances]
        LRI = len(RunningInstances)
        if len(RunningInstances) > 0:
          print("Found " + str(LRI) + " instances with tag   " + KN + "   set to value   " + KV)
        else:
            print("None found")
    
        for i in RunningInstances:
            {
                print(i)
            }
        # data = RunningInstances
        data = {'Instances':RunningInstances, 'Number of matching instances found' : str(LRI)}
    else:
        data = "Invalid Request"
    
        
    # TODO implement
    return {
        'statusCode': 200,
        # 'Number of matching instances found': str(LRI),
        # 'Instances found': RunningInstances
        # 'body': json.dumps(KV, default=str)
        'body': json.dumps(data, default=str)
    }
